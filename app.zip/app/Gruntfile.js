module.exports = function(grunt) {
  // Do grunt-related things in here
  grunt.initConfig({
  pkg: grunt.file.readJSON('package.json'),
  
  
 
 less: {
  development: {
    files: {
      'MyApp/css/style.css': 'MyApp/less/style-l.less'
    }
  }
 },
  // minify css
        cssmin: {
                build: {
                files: {
                    'MyApp/css/style.min.css': 'MyApp/css/style.css'
                }
            }
        },
 

		watch: {
				css: {
				files: ['MyApp/css/*.css','MyApp/less/*.less'],
				tasks: ['less','cssmin']
		}
}
  
});
  
 grunt.loadNpmTasks('grunt-contrib-less');
   grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.registerTask('default', ['watch']);
  
  
};